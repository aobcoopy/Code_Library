module.exports = {
  server: {
    command: 'http-server -p 3001 -s',
  },
};