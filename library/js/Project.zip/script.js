$(document).ready(function(){
  $('.table-fixed-header').fixedHeader();
});

//  $(window).on('resize', function () {
//    $('.header-copy').width($('.table-fixed-header').width())
//});